edad= int(input("¿Qué edad tiene?"))
if edad>=18:
    print("Usted puede Votar")
else:
    print("Usted no puede votar")