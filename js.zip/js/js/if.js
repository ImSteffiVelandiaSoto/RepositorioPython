// Ejercicio if   numero es positivo
let numero = prompt("Digite un número: ");

if (numero > 0) {
    console.log("El numero " + numero + " es positivo")
} else if (numero == 0) {
    console.log("El numero " + numero + " es neutro")
} else {
    console.log("El numero " + numero + " es negativo")
}



