//Ejercicio 2 pasar de celsius a Fahrenheit
let celsius =25;
let fahrenheit;
fahrenheit= (celsius*9/5)+32;
console.log(celsius + "° celsius equivalen a "+ fahrenheit + "° fahrenheit");

// 25° celsius equivalen a x° fahrenheit