//Ejercicio sumar dos numeros

let numero1 = 45;
let numero2 = 4;
let suma;
suma =numero1+numero2;
console.log("El valor de la suma es: "+ suma)

