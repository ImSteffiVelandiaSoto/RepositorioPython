//Ejercicio 3 area de triangulo
let base=3;
let altura=6;
let area;
area= (base*altura)/2;
console.log("El area del triangulo es: "+area)
