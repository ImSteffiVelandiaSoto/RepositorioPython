//vamos a saludar
let nombre;
x= prompt("¿Cúal es tu nombre?")
console.log("Hola "+ nombre+" Como estas?")