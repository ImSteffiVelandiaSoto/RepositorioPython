function saludo (nomUsuario){
  console.log("Hola estimado "+ nomUsuario)  
}


let nombre= prompt("Por favor digite su nombre: ")
saludo(nombre)





